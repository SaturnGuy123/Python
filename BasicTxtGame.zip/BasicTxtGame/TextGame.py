import time


while True:

    print (" ---------------------THIS GAME IS UNDER DEVELOPEMENT------------------------- ")

    time.sleep (2)
    print (" ")
    print (" ")
    
    answer = input ("Would you like to play? (yes/no)  ")
    print (" ")

    if answer.lower().strip() == "yes":

        answer = input ("You see a Waffle House to your left, and a Haunted House to your right. Which way do you go? (left/right)  ").lower().strip()
        print (" ")
        
        if answer == "left":
            answer = input ("Congratulations, you're either a coward or you have the munchies.")
            print (" ")
            time.sleep (0.5)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break

        elif answer == "right":
            answer = input ("Nice, you aren't a coward. You see a large staircase to your left and the kitchen to your right. Which way? (left/right)  ")
            print (" ")

        if answer == "left":
            print ("You make it all the way up the stairs... almost. You fell through a rotten step and died. Good fucking job.  ")
            print (" ")
            time.sleep (0.5)
            print ("  ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break
            return_to_start(Tiddy)

        elif answer == "right":
            print ("You enter the kitchen and surprise surprise its empty. Nobody has been home for a while.  ")
            print (" ")

            time.sleep (1.5)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        answer = input ("What do you want to do in the kitchen? There is a fridge and a door to another room. (fridge/leave)  ")
        print (" ")

        if answer == "fridge":
            print ("You have been raped by whatever the hell was sitting in the fridge. The dong was so big it ripped through your ass and you bled out. Sucks to be you  ")
            print (" ")
            time.sleep (0.5)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break

        elif answer == "leave":
            print ("You leave the room and enter the next one. It's also pretty empty aside from a couple shelves and yet another door to another room")
            print (" ")

            time.sleep (1.5)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        answer = input ("You can rummage through the shelves, or go to the next room. What do you do? (rummage/leave)  ")
        print (" ")

        if answer == "rummage":
            print ("After a bit of rummaging you find a key. Maybe its for something important?")
            print (" ")


        elif answer == "leave":
            print ("The door is locked. Now you are trapped forever because fuck you.  ")
            time.sleep (0.5)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break

            time.sleep (1)

            
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        answer = input ("Do you use the lock on the door? (yes/no)  ")
        print (" ")

        if answer == "yes":
            print ("You unlock the door with the key. Good Job. No, really, Good Job. I'm serious.")
            print (" ")

        elif answer == "no":
            print ("Well guess you're just gonna sit here then..")
                
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        answer = input ("Now that you unlocked the door, do you actually want to enter the room? (yes/no)  ")
        print (" ")

        if answer == "yes":
                print ("You enter the room and see a sword. It looks pretty cool")
                print (" ")


        elif answer == "no":
            print ("What are you, a chicken? Fine. Guess you'll stay here forever.  ")
            time.sleep (0.5)
            print (" ")
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        answer = input ("Do you want to take the cool sword? (yes/no)  ")
        print (" ")

        if answer == "yes":
            print ("You take the cool sword")
            print (" ")

        elif answer == "no":
            print ("You don't take the cool sword and instead progress into the next room")
            print (" ")

                    

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                      

        print ("With the cool sword you now enter the next room. Nothing is of interest at a glance  ")
        time.sleep (0.5)
        print ("That is.. until you look closer. There is a book and an ugly ass statue. The nose on the statue is crooked...  ")
        print (" ")
        time.sleep (0.4)

        answer = input ("Do you read the book or touch the nose on the statue?  (read/touch)  ")
        print (" ")

        if answer == "read":
            print ("You open the book and read some of the strange latin words. You summon a demon who then pulls you to Hell to suffer forever  ")
            print (" ")
            time.sleep (0.55)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break
        
        elif answer == "touch":
            print ("You touch the statue nose. it shifts back into place and holy shit a hidden door opened.")



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        answer = input ("Now that a secret door has opened you hear strange noises coming from it. Obviously you've come this far, so you should go into it... right?  (yes/no)  ")
        print (" ")

        if answer == "yes":
            print ("Oh sweet, i really wanted to see what is down there. You slowly wander through the hall hidden behind the door until you come to a staircase.")
            time.sleep (0.4)
            print ("You walk down the staircase slowly, the noises getting louder and louder. They sound like whispers and silent screams.")
            time.sleep (0.4)
            print ("Going further and furhter down, you finally see a light. There is a large, dungeon like room full of jail cells.")


        elif answer == "no":
            print ("Wow, i thought you were cooler than that...")
            print (" ")
            time.sleep (0.4)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break
        
    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        answer = input ("Do you want to investigate the room further. At this point even I am a little creeped out so i wont blame you if you say no...  (yes/no)  ")
        print (" ")

        if answer == "yes":
            print ("Venturing further into the creepy ass dungeon, you begin to look into the jail cells. You see lost souls, perhaps people like you, who have wandered in and gotten trapped forever.")
            print (" ")
            time.sleep (0.5)
                                        

           

        elif answer == "no":
            print ("OK, you exit through a door that magically led to outside. You were then promptly arrested for breaking and entering and burglary. Better than dying.  ")
            print (" ")
            time.sleep (0.4)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break
            

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        answer = input ("Suddenly, one of the lost souls yells at you. 'You there! You have the holy sword! Have you come to stop the demon that has imprisoned us?'  (yes/no)  ")
        print (" ")

        if answer == "yes":
            print ("The soul seems overjoyed at your answer. What a brave person you are. It then says, 'Hoorah! Our Savior has come at last! Please, slay the demon. Just continue until you see an extremely obvious door'  ")
            

        elif answer == "no":
            print ("The soul is displeased with your answer and curses you, trapping your soul in one of the cells nearby  ")
            print (" ")
            time.sleep (0.5)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            break





        answer = input ("After getting instructions to the demon's room, you just keep walking around until you spot it. Obvious was an understatement. The door is made of a strange metal and is at least 12 feet tall. It has bigass torches on either side and a pentagram on the the wall above it.  (enter/run)  ")
        print (" ")

        if answer == "enter":
            print ("Upon entering the demon's room you see him. Dude is ugly as hell, 7 feet tall with some massive horns, and a stupid looking hat. He notices you and says in a completely normal sounding voice 'Who the fuck are you? No really, i can't see that far without my glasses. I lost them. Help me find them will ya?' ")

        elif answer == "run":
            print ("Wow, you're really gonna do that to the poor lost soul? Didn't you see how happy it was when you said you'd help? Shame on you.")
            print (" ")
            time.sleep (0.5)
            print (" ~~~~~~~~~~~~~~~~~~THE END~~~~~~~~~~~~~~~~~ ")
            
        

#Honestly at this point i'm running out of ideas for the story.

























        


    else:
        print ("Pussy")
                        
                     
                        
    break
